# VMware 磁盘不足与稳定性复验

2026-09-29 用户粘贴的终端记录：VMware Ubuntu 内核 6.8.0-142-generic，活动 BPF LSM；真实响应测试 executed/passed=true，退出码0。三轮确认后的30次新打开全部 EPERM，TTL 后30次打开成功，三轮已有 fd 读取成功，非匹配打开正常。初始33次访问均成功，首次阻断率0/3，不能宣称首次攻击被阻断。记录来自用户终端，并非本机直接采集的原始数据库。

随后重建通过，但 --native-data、3600秒综合验收返回 ENOSPC：汇总 JSON 和归档目录创建均失败。一小时稳定性未验收通过；具体失败阶段和持续时长没有完整日志，不能据此断言监控器崩溃或出现事件丢失。原版 TemporaryDirectory 在归档失败时也会清理临时数据，原始记录可能已无法恢复。

## 修复

- scripts/acceptance_storage.py：按目标打开次数估算空间，8192字节/次加512MiB保留量，仅为保守预算，不是实际每事件成本结论。
- 综合测试与独立稳定性测试在运行前预检；稳定性每次资源采样检查至少512MiB余量，低于门槛则失败并停止产生负载。
- --stability-opens-per-second 显式传递负载，默认仍为1000，没有自动降低验收负载。
- 本地同文件系统归档使用重命名，避免第二份完整数据库；跨文件系统复制预检空间，归档/元数据失败时保留临时目录并打印位置。成功才清理临时目录。
- 结果写入失败时将 JSON 打印到终端并返回非零，不重复抛出掩盖原因的写入异常。

本机修复验证：Linux 83项测试通过（原77项加6项空间/归档回归检查）；2秒、100次/秒真实采集烟测生成200条、保存200条、passed=true。没有因此新增一小时通过结论，没有改变内核阻断逻辑。本次修改后的脚本不再属于之前 source-sha256.json 的代码快照。

## 复验

先检查块空间和 inode，不批量删除已有实验结果：

```bash
df -h / /tmp "$HOME"
df -i / /tmp "$HOME"
sudo du -xhd1 /tmp "$HOME/ebpf-monitor-v4/out" /var 2>/dev/null
```

更新补丁到 ~/ebpf-monitor-v4 后，1000次/秒的一小时空间预算约28GiB，建议先确保输出所在分区至少30GiB可用。Ubuntu项目已在本地Linux磁盘时直接写out，省去临时归档：

```bash
cd ~/ebpf-monitor-v4
RUN="out/vmware-acceptance-$(date +%Y%m%d-%H%M%S)"
sudo python3 scripts/acceptance_v4.py \
  --require-enforce --stability-seconds 3600 \
  --stability-opens-per-second 1000 --out "$RUN"
STATUS=$?
echo "退出码：$STATUS"
cat "$RUN/acceptance.json"
cat "$RUN/stability/result.json"
```

如果空间仅能达到约4GiB，可显式改为 --stability-opens-per-second 100；这属于每秒100次打开的持续测试，不等价于每秒1000次的验收条件。空间预算不足会在开始前拒绝，不需盲目重跑一小时。
